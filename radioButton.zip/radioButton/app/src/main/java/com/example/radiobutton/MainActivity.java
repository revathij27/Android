package com.example.radiobutton;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private CheckBox ch1, ch2;
    private EditText edit;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        radioGroup = findViewById(R.id.rg);
        ch1 = findViewById(R.id.cb1);
        ch2 = findViewById(R.id.cb2);
        edit = findViewById(R.id.ed);
    }

    public void submit(View v) {
        //find the id of the currently selected radio button
        int selectedID = radioGroup.getCheckedRadioButtonId();
        //Assign it to variable "selected“ by finding id
        RadioButton selected = findViewById(selectedID);
        //Extract the text from the radio button
        String selected_text = selected.getText().toString();
        StringBuilder ch_text= new StringBuilder();
        if(ch1.isChecked())
        {
            ch_text.append(ch1.getText()).append(" ");
        }
        if(ch2.isChecked())
        {
            ch_text.append(ch2.getText()).append(" ");
        }
        edit.setText("Selected Course: " + selected_text + "Selected Category: " +ch_text);
    }
}