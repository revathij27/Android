package com.example.video;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.net.Uri;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void playVideo(View v){
        VideoView vv = findViewById(R.id.vv1);
        String videoUrl = "https://cdn.pixabay.com/video/2016/04/02/2637-161442811_medium.mp4";
        Uri uri = Uri.parse(videoUrl);
        vv.setVideoURI(uri);
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(vv);
        mediaController.setMediaPlayer(vv);
        vv.setMediaController(mediaController);
        vv.start();
    }
}