package com.example.prgm18;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class broadcast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals("com.example.prgm18.CUSTOM_INTENT")){
            String message = intent.getStringExtra("Message");
            Toast.makeText(context, "Recieved"+message, Toast.LENGTH_SHORT).show();
        }
    }
}
