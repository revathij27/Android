package com.example.program2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText m1;
    private EditText m2;
    private EditText m3;
    private Button calc;
    private TextView sum;
    private TextView avg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        m1 = findViewById(R.id.ed1);
        m2 = findViewById(R.id.ed2);
        m3 = findViewById(R.id.ed3);
        calc = findViewById(R.id.button);
        sum = findViewById(R.id.td1);
        avg = findViewById(R.id.td2);

        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = m1.getText().toString();
                String s2 = m2.getText().toString();
                String s3 = m3.getText().toString();

                if (!s1.isEmpty() && !s2.isEmpty() && !s3.isEmpty()) {
                    int subject1 = Integer.parseInt(s1);
                    int subject2 = Integer.parseInt(s2);
                    int subject3 = Integer.parseInt(s3);

                    int sum1 = subject1 + subject2 + subject3;
                    double average = sum1 / 3.0;

                    sum.setText("Sum: " + sum1);
                    avg.setText("Average: " + average);
                }
            }
        });
    }
}

